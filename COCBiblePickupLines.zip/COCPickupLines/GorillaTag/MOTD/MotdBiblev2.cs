﻿using BepInEx;
using GorillaExtensions;
using System;
using TMPro;
using UnityEngine;

namespace GorillaTag.MOTD
{
    [BepInPlugin("m", "ccdBiblev2", "1.3.0")]
    public class MotdBiblev2 : BaseUnityPlugin
    {
        private TextMeshPro txt;
        private float colorTimer = 0f;
        private readonly Color startColor = new Color(0.5f, 0f, 1f);
        private readonly Color endColor = new Color(0.8f, 0.6f, 1f);

        private readonly string[] verses = new string[]
        {
            "Is it hot in here, or is that just the Holy Spirit burning inside you?",
            "I was reading Numbers last night, and I realized I don’t have yours.",
            "You must be made of water, because Jesus turned you into fine.",
            "I think you dropped something… my jaw, when I saw you.",
            "You put the 'stud' in Bible study.",
            "How many times do I have to walk around you to make you fall for me like Jericho?",
            "You and me — we’d make a pretty good 'pair' of disciples.",
            "Call me Jacob, because I’m wrestling with the feeling of falling for you.",
            "Is your name Grace? Because you’re amazing.",
            "Girl, you’re like manna from heaven — you’re all I need to survive.",
            "I was blinded by your beauty... like Paul on the road to Damascus.",
            "You must be an angel, because your presence is heavenly.",
            "You’re the answer to my prayers — and I didn’t even fast for this one.",
            "Are you from the Promised Land? Because you’re milk and honey to my soul.",
            "You must be Psalm 23, because you restore my soul.",
            "You must be faith, because you’re the evidence of things I’ve hoped for.",
            "I think you’re a Proverbs 31 kind of woman.",
            "You’re like a burning bush — you caught my attention and I can’t look away.",
            "Even Solomon in all his splendor wasn’t dressed like you.",
            "You must be a temple, because I want to treat you with reverence.",
            "I don’t need a fleece to know you’re the sign I’ve been waiting for.",
            "You and I would make a great covenant.",
            "Girl, are you water? Because you turned my desert into an oasis.",
            "When God said ‘It’s not good for man to be alone,’ I think He was talking about me finding you.",
            "You must be from Bethlehem, because your presence feels like Christmas.",
            "You’re like the armor of God — protecting my heart.",
            "Even Job had patience, but I can’t wait another day to talk to you.",
            "You must be the promised one, because you’re everything I prayed for.",
            "I think we’d make a great verse together — you complete my psalm.",
            "I feel like Peter — because I just fell for you hard.",
            "Are you a fisher of men? Because you’ve caught my heart.",
            "Girl, your name must be Faith, because you’re the substance of things I’ve hoped for.",
            "I was lost, but then you found me.",
            "You shine brighter than Moses’ face coming down from the mountain.",
            "If beauty were a fruit, you’d be the forbidden one (but I’d still pick you).",
            "You must be the reason Solomon wrote Song of Songs.",
            "If I had to walk on water to get to you, I’d try.",
            "Girl, I’d give up my rib for you.",
            "You’ve got me speaking in tongues — and I haven’t even been to church yet.",
            "Your love is like agape — pure and unconditional.",
            "I didn’t believe in love at first sight... until God introduced me to you.",
            "Even the walls of Jericho couldn’t keep me from you.",
            "You must be a psalmist, because you make my heart sing.",
            "Your smile is proof that God’s plan is perfect.",
            "Are you bread? Because you’re daily and I can’t live without you.",
            "You’re the ‘Amen’ to my prayers.",
            "You must be the armor of God — because you’ve protected me from loneliness.",
            "Is your name Mercy? Because you’re new every morning.",
            "You and me? That’s divine intervention."
        };

        private void Update()
        {
            if (txt == null)
            {
                FindMotdText();
            }

            if (txt != null)
            {
                AnimateColor();
                UpdateMessage();
            }
        }

        private void FindMotdText()
        {
            GameObject gameObject = GameObject.Find("COCBodyText_TitleData");
            if (gameObject != null)
            {
                txt = gameObject.GetComponent<TextMeshPro>();
                if (txt != null)
                {
                    txt.alignment = TextAlignmentOptions.Center;
                    txt.enableWordWrapping = true;
                    txt.enableVertexGradient = true;
                    txt.margin = new Vector4(0f, 0f, 0f, 100f);
                }
            }

            var display = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COCBodyText_TitleData")?.GetComponent<PlayFabTitleDataTextDisplay>();
            if (display != null)
            {
                display.enabled = false;
            }
        }

        private void UpdateMessage()
        {
            if (txt != null)
            {
                int index = DateTime.UtcNow.DayOfYear % verses.Length;
                string verse = verses[index].ToUpper();

                // Display verse and signature cleanly
                txt.text = verse + "\nMade by ThatOneGuy";
            }
        }

        private void AnimateColor()
        {
            if (txt != null)
            {
                colorTimer += Time.deltaTime * 0.5f;
                float t = (Mathf.Sin(colorTimer) + 1f) / 2f;
                Color color = Color.Lerp(startColor, endColor, t);
                txt.colorGradient = new VertexGradient(color, color, color, color);
            }
        }
    }
}
